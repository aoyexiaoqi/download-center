# 《最后的人》竖屏 MV

海边洗衣店的女孩照旧摆出两只搪瓷杯。等滚筒停下，她把一直空着的那只倒扣，带着自己的杯子出门。

本片使用用户上传的《爱着爱着就散了.mp3》，取原音频 00:49.70–01:44.70。剪辑基于这一录音的演唱，包含副歌前完整一句和第一遍副歌。成片规格为 55 秒、1080 × 1920、30 fps、H.264/AAC。

## 工程文件

- `timeline.json` 记录音频裁切、节拍参考和逐行歌词时间。歌词根据上传录音整理。时间以片内起点为零。
- `scene.js` 编排镜头、转场和歌词，`water.js` 绘制旋转的滚筒和海浪，`cup.js` 绘制手握杯、翻杯和放稳的动作。
- `assets/` 包含生成的水彩场景画和局部动作坐标。
- `render.cjs` 用 Playwright 驱动 Chromium 逐帧绘制 Canvas 画面，再用 FFmpeg 合成音频和 MP4。
- `VERIFICATION.md` 记录成片检查。

## 本地渲染

安装 Node.js 22 或更新版本、Chromium、FFmpeg 和 FFprobe，并安装 Noto Serif CJK SC 或 Noto Sans CJK SC。运行以下命令，将音频路径换成原录音的位置。

```sh
npm install
CHROME_BIN=/usr/bin/chromium npm run render -- "/path/to/爱着爱着就散了.mp3" "./last-person-mv.mp4"
```

在正式命令最后加 `--preview` 可输出 540 × 960 的低分辨率预览。可以用系统的实际 Chromium 或 Chrome 路径设置 `CHROME_BIN`。

分镜、卡点和短段动作检查沿用参考教程的流程。画面使用 AI 水彩原画及 Canvas 2D 动画，逐帧渲染由 Playwright 调度。 [参考教程](https://xhslink.cn/o/A8yNPEmGaUc)
