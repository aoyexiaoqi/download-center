(() => {
  "use strict";

  const WIDTH = 1080;
  const HEIGHT = 1920;
  const DEFAULT_GROUND = 1465;
  const CUP_X = 537;
  const HANDLE_X = 143;
  const HANDLE_Y = -42;
  const mugSize = 485;
  const mugCenter = 242;
  const bound = new Path2D(
    "M-129 -124 C-132 -43 -115 40 -105 92 C-100 135 92 138 102 95 " +
    "C112 43 130 -47 129 -124 Z"
  );
  const hull = [
    [-129, -123], [-110, -143], [-70, -151], [0, -155], [70, -151], [110, -144],
    [128, -124], [181, -93], [207, -64], [201, -27], [171, 5], [122, 32],
    [102, 95], [88, 115], [57, 121], [0, 126], [-58, 121], [-91, 112], [-105, 92]
  ];

  const clamp = (value) => Math.max(0, Math.min(value, 1));
  const lerp = (start, end, progress) => start + (end - start) * progress;
  const smooth = (start, end, time) => {
    const position = clamp((time - start) / (end - start));
    return position * position * (3 - 2 * position);
  };
  const random = (index) => {
    const n = Math.sin(index * 127.1 + 311.7) * 43758.5453123;
    return n - Math.floor(n);
  };

  function colorStops(gradient, stops) {
    for (const [position, color] of stops) gradient.addColorStop(position, color);
    return gradient;
  }

  function fillPath(ctx, points, pigment) {
    ctx.fillStyle = pigment;
    ctx.fill(new Path2D(points));
  }

  function strokePath(ctx, points, color, width) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke(new Path2D(points));
  }

  function ellipse(ctx, x, y, radiusX, radiusY, style) {
    ctx.beginPath();
    ctx.ellipse(x, y, radiusX, radiusY, 0, 0, Math.PI * 2);
    ctx.fillStyle = style;
    ctx.fill();
  }

  function freckles(ctx, count, x, y, width, height, palette, seed) {
    for (let i = 0; i < count; i++) {
      const sample = seed + i * 5;
      const px = x + width * random(sample);
      const py = y + height * random(sample + 1);
      const radius = 0.45 + 2 * random(sample + 2) ** 2;
      ctx.fillStyle = palette[i % palette.length];
      ctx.fillRect(px, py, radius * (1 + random(sample + 3)), radius);
    }
  }

  function createMug(overturned = false) {
    const raster = document.createElement("canvas");
    raster.width = mugSize;
    raster.height = mugSize;
    const ctx = raster.getContext("2d");
    ctx.translate(mugCenter, mugCenter);

    const handle = "M 111 -78 C 146 -113 196 -110 204 -73 C 217 -31 173 9 110 27 " +
      "L 109 7 C 154 -9 193 -38 185 -67 C 181 -91 150 -85 124 -61 Z";
    const handlePaint = colorStops(ctx.createLinearGradient(126, -103, 193, 7), [
      [0, "#e2cfac"], [0.50, "#c8af91"], [1, "#a18876"]
    ]);
    fillPath(ctx, handle, handlePaint);
    strokePath(ctx, handle, "#55505a", 3);
    strokePath(ctx, "M129 -78 C159 -104 189 -102 200 -76", "#e6d5b5", 4.5);
    strokePath(ctx, "M118 15 C155 4 182 -16 192 -40", "#b7a68e", 4);

    const enamel = colorStops(ctx.createLinearGradient(-138, 22, 123, -8), [
      [0, "#997c6c"], [.18, "#c4ad98"], [.39, "#dfcdb0"],
      [.59, "#e4d5bb"], [.78, "#d8c6a8"], [1, "#a68d79"]
    ]);
    ctx.fillStyle = enamel;
    ctx.fill(bound);
    ctx.save();
    ctx.clip(bound);
    const stain = colorStops(ctx.createLinearGradient(6, -120, 4, 127), [
      [0, "rgba(75,90,101,0.30)"], [.26, "rgba(75,90,101,0.00)"],
      [.67, "rgba(137,78,57,0.00)"], [1, "rgba(108,65,53,0.32)"]
    ]);
    ctx.fillStyle = stain;
    ctx.fillRect(-139, -156, 279, 286);
    const highlight = colorStops(ctx.createLinearGradient(-92, 0, 70, 0), [
      [0, "rgba(251,229,187,0)"], [.55, "rgba(251,229,187,0.48)"],
      [.79, "rgba(245,218,186,0.11)"], [1, "rgba(245,218,186,0)"]
    ]);
    fillPath(ctx, "M-93 -120 Q-81 -32 -60 105 Q-4 131 37 112 Q52 30 70 -122 Z", highlight);
    freckles(ctx, 1700, -135, -145, 270, 273,
      ["#76574222", "#604f542a", "#f4e4c53f", "#9c755422", "#f3e3c229"], 529);
    strokePath(ctx, "M-113 -85 C-111 -26 -96 51 -90 73", "#e1c2a9", 3);
    strokePath(ctx, "M87 -30 Q80 59 67 90", "rgba(103,75,66,.45)", 3);
    strokePath(ctx, "M-76 88 Q-72 101 -62 106 M-45 115 L-36 115 M83 89 L78 101", "#675853", 2.4);
    ctx.restore();
    ctx.strokeStyle = "#4a4349";
    ctx.lineWidth = 3.9;
    ctx.stroke(bound);
    strokePath(ctx, "M-104 98 Q-75 126 1 126 Q72 127 102 98", "#5e5150", 4.5);
    strokePath(ctx, "M-105 95 Q-59 116 -9 115 Q50 115 95 102", "#d3b89e", 3);

    if (overturned) {
      ellipse(ctx, 0, 105, 100, 23, "#523f42");
      ellipse(ctx, 0, 105, 94, 20.5, "#baa58e");
      ellipse(ctx, 0, 105, 77, 15.5, "#c6b097");
      strokePath(ctx, "M-57 116 Q-3 124 48 116", "#dfcbb0", 2.6);
      const lip = "M-129 -121 C-128 -136 -119 -149 -91 -153 C-49 -160 52 -160 96 -151 " +
        "Q127 -145 129 -121 Q60 -109 -7 -111 Q-73 -109 -129 -121 Z";
      const glaze = colorStops(ctx.createLinearGradient(-125, -130, 127, -130), [
        [0, "#494d5c"], [.26, "#526a7e"], [.52, "#6e8795"], [.84, "#526674"], [1, "#384956"]
      ]);
      fillPath(ctx, lip, glaze);
      strokePath(ctx, "M-128 -132 Q-121 -150 -86 -152 Q-21 -159 47 -154 Q115 -152 129 -129",
        "#344553", 3.4);
      strokePath(ctx, "M-122 -130 Q-51 -139 12 -137 Q78 -139 112 -128", "#a7a7a0", 1.8);
      fillPath(ctx, "M59 -150 L70 -152 L77 -149 L75 -142 L67 -145 L64 -142 Z", "#8d796c");
      return raster;
    }

    ellipse(ctx, 0, -122, 131.5, 34, "#334955");
    const interior = colorStops(ctx.createLinearGradient(0, -150, 0, -96), [
      [0, "#766b68"], [.4, "#504d51"], [.72, "#384955"], [1, "#687687"]
    ]);
    ellipse(ctx, 0, -123, 122, 25.8, interior);
    strokePath(ctx, "M-126 -121 C-112 -88 108 -83 126 -119", "#293e50", 6.5);
    strokePath(ctx, "M-124 -131 C-92 -158 85 -159 121 -131", "#72909e", 3);
    strokePath(ctx, "M-104 -109 Q-16 -87 68 -101", "#879a9e", 2);
    strokePath(ctx, "M-52 -149 Q3 -154 37 -149", "#c4c4b0", 2.5);
    fillPath(ctx, "M64 -150 L77 -153 L82 -148 L79 -141 L74 -143 L70 -140 L64 -144 Z", "#ac9a84");
    strokePath(ctx, "M65 -147 L72 -145 L77 -149 L82 -146", "#dac3a4", 1.8);
    return raster;
  }

  const mug = createMug();
  const invertedMug = createMug(true);
  let cuffTexture;
  function makeCuffTexture() {
    const canvas = document.createElement("canvas");
    canvas.width = 220;
    canvas.height = 220;
    const ctx = canvas.getContext("2d");
    freckles(ctx, 1850, 0, 0, 220, 220,
      ["#48192129", "#43202029", "#e1aa6a34", "#6d292929", "#edaf7737"], 992);
    return canvas;
  }

  function drawHand(ctx, x, y, grip, angle, t) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);

    const wrist = "M55 -35 C92 -44 128 -47 148 -34 L166 47 C138 68 99 49 67 34 " +
      "Q39 25 33 10 Q34 -15 55 -35 Z";
    const flesh = colorStops(ctx.createLinearGradient(14, -47, 75, 59), [
      [0, "#e4b392"], [.43, "#c68d72"], [1, "#85574f"]
    ]);
    fillPath(ctx, wrist, flesh);
    strokePath(ctx, wrist, "#493b42", 3.5);

    const arm = "M141 -49 Q220 -52 292 -99 C394 -166 525 -134 694 -147 L759 159 " +
      "Q466 139 322 118 Q212 82 149 56 Q133 9 141 -49 Z";
    const canvas = colorStops(ctx.createLinearGradient(210, -117, 297, 113), [
      [0, "#693632"], [.3, "#9d4e44"], [.55, "#9f5142"], [.79, "#7e423c"], [1, "#452b31"]
    ]);
    fillPath(ctx, arm, canvas);
    ctx.save();
    ctx.clip(new Path2D(arm));
    if (!cuffTexture) cuffTexture = makeCuffTexture();
    ctx.fillStyle = ctx.createPattern(cuffTexture, "repeat");
    ctx.fillRect(130, -177, 670, 367);
    strokePath(ctx, "M170 -32 C240 -38 281 -66 310 -81 M172 19 Q234 3 291 9 M286 84 Q385 112 484 115",
      "#bf6e56", 3.5);
    strokePath(ctx, "M182 34 C256 36 307 83 431 98 M253 -17 C376 -71 458 -63 544 -69",
      "#61353a", 5);
    strokePath(ctx, "M361 -78 Q409 -97 493 -98 M476 110 Q557 121 584 114", "#bd7054", 2.6);
    ctx.restore();
    strokePath(ctx, arm, "#47333c", 3.5);
    strokePath(ctx, "M150 -45 Q146 3 158 51 M162 -44 Q157 3 171 53", "#2e2d37", 3);
    strokePath(ctx, "M166 -34 Q163 3 176 39", "#c17764", 2);

    const tip = lerp(-68, -25, grip);
    const digit = lerp(-88, -48, grip);
    const high = lerp(-54, -32, grip);
    const thumb = lerp(-64, -33, grip);
    const lower = lerp(36, 19, grip);

    const fingerShape = `M74 -35 C33 -47 4 -47 ${digit + 8} ${high}
      Q${digit - 9} ${high + 2} ${digit} ${high + 15}
      C${digit + 10} ${high + 22} -42 -10 -14 -9
      Q-4 3 -16 14 Q-45 8 ${thumb} ${lower}
      Q${thumb - 4} ${lower + 10} ${thumb + 6} ${lower + 15}
      Q-36 46 -6 39 C27 47 43 26 66 26 Q84 3 74 -35 Z`;
    fillPath(ctx, fingerShape, flesh);
    strokePath(ctx, fingerShape, "#553b40", 3.3);
    strokePath(ctx, `M${digit + 5} ${high + 15} Q-41 -10 -18 -12 Q-4 -14 13 -7
      M${thumb + 6} ${lower + 15} Q-21 36 5 24`, "#885953", 2.5);

    const lead = `M48 -31 Q11 -37 ${tip + 15} ${high + 3}
      Q${tip - 9} ${high + 9} ${tip} ${high + 21}
      C${tip + 10} ${high + 26} -19 -7 10 -5
      Q29 2 44 -4 Z`;
    fillPath(ctx, lead, flesh);
    strokePath(ctx, lead, "#664746", 2.8);
    strokePath(ctx, `M${tip + 6} ${high + 11} Q${tip + 13} ${high + 8} ${tip + 22} ${high + 10}`, "#f1c4aa", 3);
    strokePath(ctx, "M19 24 Q39 19 47 11 M27 -22 L17 -23", "#e8a283", 2);
    ctx.globalAlpha = 0.12 + Math.sin(t * 2.2) * 0.035;
    freckles(ctx, 32, 25, -24, 55, 45, ["#ffddc2", "#532c3650"], 411);
    ctx.restore();
  }

  function fallbackPlate(ctx, ground) {
    const walls = colorStops(ctx.createLinearGradient(0, 0, 1033, 1351), [
      [0, "#324753"], [.38, "#344953"], [.7, "#657276"], [1, "#4b5255"]
    ]);
    ctx.fillStyle = walls;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
    ctx.fillStyle = "#4b4847";
    ctx.fillRect(132, 0, 24, ground);
    ctx.fillRect(940, 0, 47, ground);
    ctx.fillStyle = "#adb0a338";
    ctx.fillRect(166, 0, 11, ground);
    ctx.fillRect(900, 0, 25, ground);
    for (let i = 0; i < 145; i++) {
      const x = random(i + 654) * WIDTH;
      const y = random(i + 2341) * (ground - 35);
      const dr = random(i + 7639);
      strokePath(ctx, `M${x} ${y} l${-2 + dr * 4} ${13 + dr * 65}`,
        i % 5 ? "#a3b6b42f" : "#c0d1c562", 0.8 + 3 * dr);
    }
    const sill = colorStops(ctx.createLinearGradient(0, ground - 55, 26, ground + 215), [
      [0, "#3e3438"], [.24, "#826651"], [.55, "#a58266"], [.66, "#614740"], [1, "#49383a"]
    ]);
    fillPath(ctx, `M0 ${ground - 51} L1080 ${ground - 36} L1080 1920 L0 1920 Z`, sill);
    for (let i = 0; i < 72; i++) {
      const x = random(i + 723) * WIDTH;
      const y = ground - 26 + random(i + 682) * (HEIGHT - ground + 26);
      const length = 50 + random(i + 145) * 266;
      strokePath(ctx, `M${x} ${y} q${length * .58} -7 ${length} -3`,
        i % 5 ? "#362e3240" : "#d7af8479", i % 3 + 0.5);
    }
  }

  function drawPlate(ctx, image, ground) {
    if (!image || !image.naturalWidth) {
      fallbackPlate(ctx, ground);
      return;
    }
    const scale = Math.max(WIDTH / image.naturalWidth, HEIGHT / image.naturalHeight);
    const width = image.naturalWidth * scale;
    const height = image.naturalHeight * scale;
    ctx.drawImage(image, (WIDTH - width) / 2, (HEIGHT - height) / 2, width, height);
  }

  function drawCupShot(ctx, localSeconds, shotDuration, assets = {}) {
    const time = localSeconds / Math.max(shotDuration, .001);
    const ground = assets.cupGround ?? DEFAULT_GROUND;
    const cupX = assets.cupX ?? CUP_X;
    drawPlate(ctx, assets.cup, ground);

    const turn = smooth(.36, .64, time);
    const angle = -Math.PI * turn;
    const height = 253 * smooth(.28, .44, time) * (1 - smooth(.60, .75, time));
    const cosine = Math.cos(angle);
    const sine = Math.sin(angle);
    const edge = Math.max(...hull.map(([x, y]) => x * sine + y * cosine));
    const x = cupX + 15 * Math.sin(Math.PI * turn);
    const y = ground - edge - height;
    const shadowAlpha = lerp(.44, .13, height / 253);

    ctx.save();
    ctx.translate(x + 15 + height * .13, ground + 10);
    ctx.scale(1, .22);
    const shadowRadius = 160 + height * .25;
    const shadow = colorStops(ctx.createRadialGradient(0, 0, 13, 0, 0, shadowRadius), [
      [0, `rgba(41,32,41,${shadowAlpha})`], [.45, `rgba(41,32,41,${shadowAlpha * .76})`],
      [1, "rgba(41,32,41,0)"]
    ]);
    ellipse(ctx, 0, 0, shadowRadius, shadowRadius, shadow);
    ctx.restore();

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    const invertView = smooth(.72, .98, turn);
    if (invertView < 1) ctx.drawImage(mug, -mugCenter, -mugCenter);
    if (invertView > 0) {
      ctx.globalAlpha = invertView;
      ctx.drawImage(invertedMug, -mugCenter, -mugCenter);
    }
    ctx.restore();

    const enter = smooth(.12, .24, time);
    const release = smooth(.76, .85, time);
    const exit = smooth(.84, .97, time);
    if (enter > 0 && exit < 1) {
      const handleX = x + HANDLE_X * cosine - HANDLE_Y * sine;
      const handleY = y + HANDLE_X * sine + HANDLE_Y * cosine;
      const palmAngle = -.11 - .46 * Math.sin(Math.PI * turn);
      const reachX = (1 - enter) * 560 + exit * 845 + release * 15;
      const reachY = (1 - enter) * -65 - exit * 265 - release * 28;
      drawHand(ctx, handleX + 37 + reachX, handleY + 18 + reachY,
        enter * (1 - release), palmAngle, localSeconds);
    }
  }

  window.drawCupShot = drawCupShot;
})();
