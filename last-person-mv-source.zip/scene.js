(() => {
  const canvas = document.querySelector('canvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const width = canvas.width;
  const height = canvas.height;
  const assets = {};

  const clamp = (value) => Math.min(1, Math.max(0, value));
  const ease = (value) => {
    const k = clamp(value);
    return k * k * (3 - 2 * k);
  };
  const blend = (a, b, k) => a + (b - a) * k;
  const hash = (n) => {
    const value = Math.sin(n * 12.9898 + 13.195) * 43758.5453;
    return value - Math.floor(value);
  };

  function loadImage(name) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        assets[name] = img;
        resolve();
      };
      img.onerror = () => reject(new Error('Missing scene plate ' + name));
      img.src = 'assets/' + name + '.jpg';
    });
  }

  function plate(name, zoom = 1, focusX = 0.5, focusY = 0.5) {
    const img = assets[name];
    const scale = Math.max(width / img.naturalWidth, height / img.naturalHeight) * zoom;
    const w = img.naturalWidth * scale;
    const h = img.naturalHeight * scale;
    ctx.drawImage(img, (width - w) * focusX, (height - h) * focusY, w, h);
  }

  function tint(rgb, opacity) {
    ctx.fillStyle = 'rgba(' + rgb + ',' + opacity + ')';
    ctx.fillRect(0, 0, width, height);
  }

  function rain(time, intensity, lanes) {
    ctx.save();
    ctx.lineCap = 'round';
    for (let i = 0; i < 54; i++) {
      const lane = lanes[i % lanes.length];
      const x = blend(lane[0], lane[1], hash(i + 2));
      const rate = 45 + hash(i + 309) * 135;
      const y = (hash(i + 21) * (height + 120) + time * rate) % (height + 120) - 60;
      const length = 6 + hash(i + 502) * 37;
      ctx.lineWidth = 0.75 + hash(i + 210) * 2.3;
      ctx.strokeStyle = 'rgba(203,230,231,' + (0.04 + hash(i + 31) * 0.13) * intensity + ')';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x - 2, y + length * 0.5, x - 4.5, y + length);
      ctx.stroke();
    }
    ctx.restore();
  }

  function steam(time, anchor, strength) {
    ctx.save();
    ctx.translate(anchor[0], anchor[1]);
    ctx.lineCap = 'round';
    for (let i = 0; i < 6; i++) {
      const breath = (time * (0.27 + i * 0.013) + hash(i + 9)) % 1;
      const y = -40 - breath * 165;
      const x = (i - 2.5) * 11 + Math.sin(time * 1.5 + i * 0.7) * 18;
      const opacity = Math.sin(breath * Math.PI) * strength;
      ctx.strokeStyle = 'rgba(237,231,202,' + opacity + ')';
      ctx.lineWidth = 3 + i * 0.85;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.bezierCurveTo(x + 18, y - 18, x - 13, y - 34, x + 8, y - 53);
      ctx.stroke();
    }
    ctx.restore();
  }

  function edgeLight(time, warm = false, gain = 1) {
    const opacity = (0.06 + (Math.sin(time * 1.2) + 1) * 0.02) * gain;
    const pos = warm ? 740 : 340;
    const light = ctx.createRadialGradient(pos, 440, 40, pos, 530, 1170);
    light.addColorStop(0, warm ? 'rgba(255,199,128,' + opacity + ')' : 'rgba(146,181,199,' + opacity + ')');
    light.addColorStop(1, 'transparent');
    ctx.fillStyle = light;
    ctx.fillRect(0, 0, width, height);
  }

  function opening(local, span) {
    const fraction = ease(local / span);
    plate('opening', 1.015 + 0.055 * fraction, 0.47, 0.60);
    rain(local, 0.85, [[38, 270], [810, 1074]]);
    edgeLight(local);
    if (assets.geometry.steam) {
      steam(local, assets.geometry.steam, 0.105);
    }
  }

  function door(local, span, second = false) {
    const fraction = ease(local / span);
    const wobble = Math.sin(local * 13) * Math.exp(-local * 1.85);
    plate('door', (second ? 1.10 : 1.03) + 0.065 * fraction,
      (second ? 0.64 : 0.43) + wobble * 0.032, second ? 0.51 : 0.34);
    rain(local + (second ? 9 : 0), second ? 0.57 : 1.08, [[22, 322], [473, 572], [780, 1063]]);
    edgeLight(local, false, 0.6);
  }

  function breakers(local, span) {
    const fraction = ease(local / span);
    plate('breakers', 1.06 + 0.10 * fraction, blend(0.36, 0.64, fraction), blend(0.43, 0.52, fraction));
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let i = 0; i < 14; i++) {
      const s = (local * 0.63 + hash(i + 96)) % 1;
      const x = 60 + hash(i + 77) * 1040 - s * 98;
      const y = 550 + hash(i + 79) * 500 + s * 200;
      ctx.globalAlpha = 0.12 * Math.sin(s * Math.PI);
      ctx.lineWidth = 0.8 + hash(i + 16) * 1.4;
      ctx.strokeStyle = '#dbdfcf';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + 20, y + 16, x + 53, y + 21);
      ctx.stroke();
    }
    ctx.restore();
  }

  function towel(local, span, close = false) {
    const fraction = ease(local / span);
    plate('towel', (close ? 1.34 : 1.025) + (close ? 0.057 : 0.095) * fraction,
      close ? 0.42 : blend(0.57, 0.38, fraction), close ? 0.23 : 0.58);
    edgeLight(local, false, 0.78);
    if (close) tint('27,40,52', 0.08);
  }

  function ending(local, span) {
    const fraction = ease(local / span);
    plate('ending', 1.085 - fraction * 0.07, 0.54, 0.66);
    edgeLight(local, true, fraction + 0.24);
    rain(local, 0.28 * (1 - fraction), [[24, 275], [879, 1070]]);
  }

  const scenes = [
    { start: 0, draw: opening, transition: 0 },
    { start: 3.33, draw: door, transition: 0.24 },
    { start: 4.85, draw: (t, d) => window.drawWaterShot(ctx, t, d, assets), transition: 0.20 },
    { start: 15.33, draw: breakers, transition: 0.43 },
    { start: 17.38, draw: towel, transition: 0.46, foam: true },
    { start: 23.18, draw: (t, d) => door(t, d, true), transition: 0.30 },
    { start: 28.62, draw: (t, d) => towel(t, d, true), transition: 0.34 },
    { start: 34.56, draw: (t, d) => window.drawCupShot(ctx, t, d, assets), transition: 0.38 },
    { start: 45.80, draw: ending, transition: 0.68 },
  ];

  function foamSwipe(local, span) {
    const k = clamp(local / span);
    const x = -420 + ease(k) * (width + 900);
    ctx.save();
    ctx.translate(x, 920);
    ctx.rotate(-0.29);
    const haze = ctx.createLinearGradient(-240, 0, 250, 0);
    haze.addColorStop(0, 'rgba(229,235,220,0)');
    haze.addColorStop(0.5, 'rgba(229,235,220,0.72)');
    haze.addColorStop(1, 'rgba(229,235,220,0)');
    ctx.fillStyle = haze;
    ctx.fillRect(-240, -1260, 490, 2520);
    ctx.restore();
  }

  function vignette() {
    const tone = ctx.createLinearGradient(0, 1240, 0, height);
    tone.addColorStop(0, 'rgba(13,21,29,0)');
    tone.addColorStop(0.70, 'rgba(13,21,29,0.30)');
    tone.addColorStop(1, 'rgba(13,21,29,0.56)');
    ctx.fillStyle = tone;
    ctx.fillRect(0, 1240, width, height - 1240);
  }

  let timeline;
  function lyric(time) {
    const cue = timeline.lyrics.find((line) => time >= line.start && time < line.end);
    if (!cue) return;
    const opacity = Math.min(ease((time - cue.start + 0.025) / 0.16),
      ease((cue.end - time + 0.025) / 0.19));
    ctx.save();
    ctx.globalAlpha = opacity;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '500 65px "Noto Serif CJK SC", "Noto Sans CJK SC", serif';
    ctx.lineWidth = 3.5;
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(25,26,29,0.75)';
    ctx.fillStyle = '#fcf0d3';
    ctx.shadowColor = 'rgba(10,13,15,0.5)';
    ctx.shadowBlur = 13;
    ctx.shadowOffsetY = 3;
    ctx.strokeText(cue.text, width / 2, 1670, 900);
    ctx.shadowColor = 'transparent';
    ctx.fillText(cue.text, width / 2, 1670, 900);
    ctx.restore();
  }

  function drawScene(scene, local, span, opacity = 1) {
    ctx.save();
    ctx.globalAlpha = opacity;
    scene.draw(local, span);
    ctx.restore();
  }

  window.drawFrame = (time) => {
    let index = scenes.length - 1;
    while (scenes[index].start > time && index > 0) index--;
    const current = scenes[index];
    const next = scenes[index + 1];
    const span = (next?.start ?? timeline.duration) - current.start;
    const local = Math.max(0, time - current.start);
    if (index > 0 && local < current.transition) {
      const previous = scenes[index - 1];
      const previousSpan = current.start - previous.start;
      drawScene(previous, previousSpan, previousSpan);
      drawScene(current, local, span, ease(local / current.transition));
      if (current.foam) foamSwipe(local, current.transition);
    } else {
      drawScene(current, local, span);
    }
    vignette();
    lyric(time);
    if (time < 0.48) tint('19,25,33', 1 - ease(time / 0.48));
    if (time > timeline.duration - 0.95) {
      tint('25,29,33', ease((time - timeline.duration + 0.95) / 0.95));
    }
  };

  window.ready = Promise.all([
    fetch('timeline.json').then((response) => response.json()),
    fetch('assets/geometry.json').then((response) => response.json()),
    document.fonts.load('500 65px "Noto Serif CJK SC"', '最后的人爱散'),
    ...['opening', 'door', 'towel', 'ending', 'washer', 'sea', 'cup', 'breakers'].map(loadImage),
  ]).then(([data, geometry]) => {
    timeline = data;
    assets.geometry = geometry;
    assets.waterGeometry = {
      ...geometry.water,
      matchFraction: (5.96 - scenes[2].start) / (scenes[3].start - scenes[2].start),
    };
    window.drawFrame(0);
    return true;
  });
})();
