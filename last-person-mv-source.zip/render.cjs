/*
 * Final render: node render.cjs /path/to/song.mp3 /path/to/final.mp4
 * Add --preview for a faster 540 × 960 review copy with the same timing.
 * Set CHROME_BIN to override the local Chromium executable.
 */

const { execFileSync, spawn } = require('node:child_process');
const { randomUUID } = require('node:crypto');
const { createReadStream } = require('node:fs');
const { mkdir, readFile, rename, rm, stat } = require('node:fs/promises');
const http = require('node:http');
const path = require('node:path');
const { chromium } = require('playwright');

const width = 1080;
const height = 1920;
const contentTypes = {
  '.css': 'text/css',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
};

async function serveProject() {
  const server = http.createServer(async (request, response) => {
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
      const filename = path.resolve(__dirname, `.${pathname === '/' ? '/index.html' : pathname}`);
      if (!filename.startsWith(`${__dirname}${path.sep}`) || !(await stat(filename)).isFile()) {
        response.writeHead(404).end();
        return;
      }
      response.writeHead(200, { 'Content-Type': contentTypes[path.extname(filename)] || 'application/octet-stream' });
      const stream = createReadStream(filename);
      stream.once('error', () => response.destroy());
      stream.pipe(response);
    } catch {
      response.writeHead(404).end();
    }
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return server;
}

function readAudioDuration(audioPath) {
  const duration = Number(execFileSync('ffprobe', [
    '-v', 'error', '-select_streams', 'a:0',
    '-show_entries', 'stream=duration', '-of', 'csv=p=0', audioPath,
  ], { encoding: 'utf8' }).trim());
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new Error(`Could not determine the duration of the audio stream in ${audioPath}`);
  }
  return duration;
}

function startEncoder({ audioPath, outputPath, audioStart, audioDuration, duration, fps, preview }) {
  const args = [
    '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
    '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', 'pipe:0',
    '-ss', String(audioStart), '-i', audioPath,
    '-map', '0:v:0', '-map', '1:a:0',
    '-vf', 'scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709',
    '-color_range', 'tv', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
    '-c:v', 'libx264', '-threads:v', '2', '-preset', preview ? 'ultrafast' : 'veryfast',
    '-crf', preview ? '23' : '18', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '256k',
  ];

  const audioFilters = [`atrim=duration=${duration}`];
  // Preserve the supplied ending when the edit runs to the end of the recording.
  if (audioStart + duration < audioDuration - 0.08) {
    const fadeDuration = Math.min(0.4, duration);
    audioFilters.push(`afade=t=out:st=${duration - fadeDuration}:d=${fadeDuration}`);
  }

  args.push('-af', audioFilters.join(','), '-movflags', '+faststart', '-f', 'mp4', outputPath);
  const process = spawn('ffmpeg', args, { stdio: ['pipe', 'ignore', 'pipe'] });
  let errors = '';
  process.stderr.setEncoding('utf8');
  process.stderr.on('data', (message) => { errors = (errors + message).slice(-8000); });
  process.stdin.on('error', () => {});

  const finished = new Promise((resolve, reject) => {
    process.once('error', reject);
    process.once('close', (code, signal) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg stopped (${signal || code}). ${errors.trim()}`));
      }
    });
  });
  finished.catch(() => {});

  return { process, finished };
}

async function makeFrameRenderer(browser, pageUrl, preview) {
  const page = await browser.newPage({ viewport: { width, height } });
  page.on('pageerror', (error) => console.error(`Scene error: ${error.message}`));
  const response = await page.goto(pageUrl);
  if (!response?.ok()) throw new Error(`Could not load the scene from ${pageUrl}.`);
  await page.waitForFunction(() => typeof window.drawFrame === 'function' && Boolean(window.ready),
    undefined, { timeout: 120_000 });
  await page.evaluate(async () => {
    await window.ready;
    await document.fonts.ready;
  });

  return page.evaluateHandle(({ width, height, preview }) => {
    const source = [...document.querySelectorAll('canvas')].find(
      (canvas) => canvas.width === width && canvas.height === height,
    );
    if (!source) throw new Error(`The scene must expose a ${width} × ${height} canvas.`);

    const output = preview ? document.createElement('canvas') : source;
    let context;
    if (preview) {
      output.width = width / 2;
      output.height = height / 2;
      context = output.getContext('2d');
    }

    return async ({ firstFrame, frameCount, fps }) => {
      const images = [];
      for (let offset = 0; offset < frameCount; offset += 1) {
        await window.drawFrame((firstFrame + offset) / fps);
        context?.drawImage(source, 0, 0, output.width, output.height);
        images.push(output.toDataURL('image/jpeg', preview ? 0.82 : 0.93).split(',')[1]);
      }
      return images;
    };
  }, { width, height, preview });
}

async function render(audioPath, outputPath, preview) {
  const { audioStart, duration, fps: renderFps } = JSON.parse(
    await readFile(path.join(__dirname, 'timeline.json'), 'utf8'),
  );
  if (!Number.isFinite(audioStart) || audioStart < 0 || !Number.isFinite(duration) || duration <= 0 ||
      !Number.isFinite(renderFps) || renderFps <= 0 || renderFps > 120) {
    throw new Error('timeline.json requires a nonnegative audioStart, a positive duration, and fps between 0 and 120.');
  }

  const audioDuration = readAudioDuration(audioPath);
  if (audioStart >= audioDuration || audioStart + duration > audioDuration + 0.08) {
    throw new Error(`The requested segment (${audioStart}s–${audioStart + duration}s) exceeds the ${audioDuration}s recording.`);
  }

  const fps = preview ? Math.min(renderFps, 12) : renderFps;
  const frameCount = Math.ceil(duration * fps - 1e-8);
  const batchSize = preview ? 24 : 12;
  const temporaryPath = path.join(path.dirname(outputPath), `.${path.basename(outputPath)}.${randomUUID()}.tmp`);
  await mkdir(path.dirname(outputPath), { recursive: true });

  let browser;
  let encoder;
  let server;
  try {
    server = await serveProject();
    browser = await chromium.launch({
      executablePath: process.env.CHROME_BIN || '/usr/bin/chromium',
      headless: true,
    });
    const drawBatch = await makeFrameRenderer(browser, `http://127.0.0.1:${server.address().port}/`, preview);
    encoder = startEncoder({ audioPath, outputPath: temporaryPath, audioStart, audioDuration, duration, fps, preview });

    let nextProgress = 0;
    for (let firstFrame = 0; firstFrame < frameCount; firstFrame += batchSize) {
      const images = await drawBatch.evaluate((draw, batch) => draw(batch), {
        firstFrame, frameCount: Math.min(batchSize, frameCount - firstFrame), fps,
      });
      const chunk = Buffer.concat(images.map((image) => Buffer.from(image, 'base64')));
      await new Promise((resolve, reject) => {
        encoder.process.stdin.write(chunk, (error) => error ? reject(error) : resolve());
      });

      const done = firstFrame + images.length;
      if (done >= nextProgress || done === frameCount) {
        console.log(`Rendered ${done}/${frameCount} frames`);
        nextProgress = done + Math.ceil(fps * 5);
      }
    }

    encoder.process.stdin.end();
    await encoder.finished;
    await rename(temporaryPath, outputPath);
    console.log(outputPath);
  } finally {
    if (encoder && encoder.process.exitCode === null && encoder.process.signalCode === null) {
      encoder.process.stdin.destroy();
      encoder.process.kill();
      await encoder.finished.catch(() => {});
    }
    await browser?.close();
    if (server) await new Promise((resolve) => server.close(resolve));
    await rm(temporaryPath, { force: true });
  }
}

async function main() {
  const [audio, output, ...flags] = process.argv.slice(2);
  if (!audio || !output || flags.length > 1 || flags.some((flag) => flag !== '--preview')) {
    throw new Error('Usage: node render.cjs <audiofile> <output.mp4> [--preview]');
  }
  const audioPath = path.resolve(audio);
  const outputPath = path.resolve(output);
  if (audioPath === outputPath || path.extname(outputPath).toLowerCase() !== '.mp4') {
    throw new Error('The output must be a new MP4 path distinct from the input audio.');
  }
  await render(audioPath, outputPath, flags.includes('--preview'));
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
