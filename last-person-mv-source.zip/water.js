(() => {
  "use strict";

  const WIDTH = 1080;
  const HEIGHT = 1920;
  const TARGET = { x: 540, y: 920 };
  const DEFAULT_WASHER = { x: 540, y: 920, radius: 288 };
  const DEFAULT_SEA = { x: 540, y: 920, radius: 370 };
  const TAU = Math.PI * 2;
  const tiles = new WeakMap();
  const seaHighlights = new WeakMap();

  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const unit = (value) => clamp(value, 0, 1);
  const smooth = (value) => {
    const x = unit(value);
    return x * x * (3 - 2 * x);
  };
  const random = (index) => {
    const value = Math.sin(index * 128.547 + 46.37) * 14585.95;
    return value - Math.floor(value);
  };

  const foamMarks = Array.from({ length: 46 }, (_, index) => ({
    angle: random(index * 9 + 1) * TAU,
    distance: 0.38 + random(index * 9 + 2) * 0.59,
    pace: 0.13 + random(index * 9 + 3) * 0.18,
    phase: random(index * 9 + 4) * TAU,
    width: 0.025 + random(index * 9 + 5) * 0.117,
    weight: 0.65 + random(index * 9 + 6) * 3.1,
    opacity: 0.11 + random(index * 9 + 7) * 0.25,
  }));

  function drawCover(ctx, image) {
    const iw = image.naturalWidth || image.width;
    const ih = image.naturalHeight || image.height;
    const scale = Math.max(WIDTH / iw, HEIGHT / ih);
    const width = iw * scale;
    const height = ih * scale;
    ctx.drawImage(image, (WIDTH - width) / 2, (HEIGHT - height) / 2, width, height);
  }

  function spinningTile(image, ring, feather) {
    let cache = tiles.get(image);
    if (!cache) {
      cache = new Map();
      tiles.set(image, cache);
    }
    const key = [ring.x, ring.y, ring.radius, feather].join(",");
    if (cache.has(key)) return cache.get(key);

    const half = Math.ceil(ring.radius) + 2;
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = half * 2;
    const ctx = canvas.getContext("2d");
    ctx.save();
    ctx.translate(half - ring.x, half - ring.y);
    drawCover(ctx, image);
    ctx.restore();

    ctx.globalCompositeOperation = "destination-in";
    const mask = ctx.createRadialGradient(half, half, ring.radius * feather, half, half, ring.radius);
    mask.addColorStop(0, "#fff");
    mask.addColorStop(1, "#fff0");
    ctx.fillStyle = mask;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    cache.set(key, canvas);
    return canvas;
  }

  function drawRotor(ctx, image, ring, angle, feather, opacity = 1) {
    const tile = spinningTile(image, ring, feather);
    ctx.save();
    ctx.translate(ring.x, ring.y);
    ctx.rotate(angle);
    ctx.globalAlpha *= opacity;
    ctx.drawImage(tile, -tile.width / 2, -tile.height / 2);
    ctx.restore();
  }

  function paleFoam(image, ring) {
    const underlay = spinningTile(image, ring, 0.7);
    if (seaHighlights.has(underlay)) return seaHighlights.get(underlay);

    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = underlay.width;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(underlay, 0, 0);
    const layer = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const rgba = layer.data;
    for (let i = 0; i < rgba.length; i += 4) {
      const lowest = Math.min(rgba[i], rgba[i + 1], rgba[i + 2]);
      rgba[i + 3] *= smooth((lowest - 125) / 88) * 0.64;
      rgba[i] = 211;
      rgba[i + 1] = 221;
      rgba[i + 2] = 207;
    }
    ctx.putImageData(layer, 0, 0);
    seaHighlights.set(underlay, canvas);
    return canvas;
  }

  function pullFoam(ctx, image, ring, seconds) {
    if (seconds <= 0) return;
    const texture = paleFoam(image, ring);
    for (const layer of [0, 1]) {
      const phase = (seconds / 3.85 + layer * 0.5) % 1;
      const travel = 1 + phase * (0.12 + 0.075 * layer);
      ctx.save();
      ctx.translate(ring.x, ring.y);
      ctx.rotate(0.09 + 0.39 * phase);
      ctx.scale(travel, travel);
      ctx.globalAlpha *= 0.36 * Math.sin(Math.PI * phase) ** 2 * smooth(seconds / 0.65);
      ctx.drawImage(texture, -texture.width / 2, -texture.height / 2);
      ctx.restore();
    }
  }

  function minCameraZoom(ring) {
    return Math.max(
      1,
      TARGET.x / ring.x,
      (WIDTH - TARGET.x) / (WIDTH - ring.x),
      TARGET.y / ring.y,
      (HEIGHT - TARGET.y) / (HEIGHT - ring.y),
    );
  }

  function placeCamera(ctx, ring, zoom) {
    ctx.translate(TARGET.x, TARGET.y);
    ctx.scale(zoom, zoom);
    ctx.translate(-ring.x, -ring.y);
  }

  function seaFoam(ctx, ring, seconds, alpha) {
    ctx.save();
    ctx.translate(ring.x, ring.y);
    ctx.lineCap = "round";
    for (const mark of foamMarks) {
      const life = (0.5 + 0.5 * Math.sin(seconds * 1.17 + mark.phase)) ** 2;
      const angle = mark.angle + mark.pace * seconds;
      const radius = ring.radius * (
        mark.distance + 0.046 * Math.sin(seconds * 0.63 + mark.phase)
      );
      const taper = mark.width * (0.65 + 0.35 * life);
      ctx.strokeStyle = `rgba(217,232,215,${alpha * mark.opacity * life})`;
      ctx.lineWidth = mark.weight * (0.75 + 0.25 * life);
      ctx.beginPath();
      ctx.arc(0, 0, radius, angle - taper, angle);
      ctx.stroke();
    }
    ctx.restore();
  }

  function fallbackSea(ctx, ring, seconds) {
    const water = ctx.createLinearGradient(90, 0, 1015, HEIGHT);
    water.addColorStop(0, "#182a31");
    water.addColorStop(0.44, "#286361");
    water.addColorStop(1, "#19353d");
    ctx.fillStyle = water;
    ctx.fillRect(-250, -250, WIDTH + 500, HEIGHT + 500);

    ctx.save();
    ctx.translate(ring.x, ring.y);
    for (let index = 0; index < 190; index++) {
      const phase = random(index + 900) * TAU;
      const radius = ring.radius * (0.1 + random(index + 1000) * 1.76);
      const width = random(index + 1200) * 0.37 + 0.025;
      const angle = phase + 0.23 * seconds + 0.05 * Math.sin(seconds + phase);
      ctx.strokeStyle = index % 5 === 0 ? "#c4d6c3a0" : "#81aaa16d";
      ctx.lineWidth = random(index + 1100) * 5.6 + 0.35;
      ctx.beginPath();
      ctx.arc(0, 0, radius, angle, angle + width);
      ctx.stroke();
    }
    ctx.restore();
  }

  function fallbackWasher(ctx, ring, angle) {
    const steel = ctx.createLinearGradient(0, 100, WIDTH, HEIGHT);
    steel.addColorStop(0, "#516b73");
    steel.addColorStop(0.48, "#65777b");
    steel.addColorStop(1, "#3b4c54");
    ctx.fillStyle = steel;
    ctx.fillRect(-200, -200, WIDTH + 400, HEIGHT + 400);
    ctx.strokeStyle = "#899092";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-100, 400);
    ctx.lineTo(WIDTH + 100, 400);
    ctx.stroke();

    ctx.save();
    ctx.translate(ring.x, ring.y);
    for (const [factor, color] of [[1.27, "#243640"], [1.23, "#959b97"], [1.14, "#6a7f83"], [1.044, "#233640"], [1, "#344f62"]]) {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(0, 0, ring.radius * factor, 0, TAU);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.arc(0, 0, ring.radius - 2, 0, TAU);
    ctx.clip();
    ctx.rotate(angle);
    for (let index = 0; index < 110; index++) {
      const phase = random(index + 100) * TAU;
      const radius = 8 + random(index + 200) * (ring.radius - 8);
      ctx.strokeStyle = index % 4 ? "#778e95aa" : "#bdd1ceed";
      ctx.lineWidth = 1 + random(index + 300) * 9;
      ctx.beginPath();
      ctx.arc(0, 0, radius, phase, phase + 0.02 + random(index + 400) * 0.75);
      ctx.stroke();
    }
    ctx.restore();
  }

  function renderWasher(ctx, seconds, match, assets, washer, sea) {
    const baseZoom = minCameraZoom(washer);
    const seaRadiusOnScreen = sea.radius * minCameraZoom(sea);
    const cutZoom = Math.max(baseZoom * 1.075, Math.min(baseZoom * 1.46, seaRadiusOnScreen / washer.radius));
    const zoom = baseZoom + (cutZoom - baseZoom) * smooth((seconds + 0.095) / Math.max(0.095, match));
    const angle = (seconds - match) * 0.86 + Math.sin((seconds - match) * 2.14) * 0.041;
    ctx.save();
    placeCamera(ctx, washer, zoom);
    if (assets.washer) {
      drawCover(ctx, assets.washer);
      drawRotor(ctx, assets.washer, washer, angle, 0.85);
      seaFoam(ctx, washer, seconds - match, 0.22);
    } else {
      fallbackWasher(ctx, washer, angle);
    }
    ctx.restore();
  }

  function renderSea(ctx, seconds, assets, sea, alpha = 1) {
    const zoom = minCameraZoom(sea) * (1 + smooth(seconds / 12) * 0.087);
    const angle = 0.16 * Math.sin(seconds * 0.95) + 0.036 * seconds;
    ctx.save();
    ctx.globalAlpha *= alpha;
    placeCamera(ctx, sea, zoom);
    if (assets.sea) {
      drawCover(ctx, assets.sea);
      drawRotor(ctx, assets.sea, sea, angle, 0.5, 0.79);
      pullFoam(ctx, assets.sea, sea, seconds);
      seaFoam(ctx, sea, seconds, 0.42 * smooth(seconds / 0.8));
    } else {
      fallbackSea(ctx, sea, seconds);
    }
    ctx.restore();
  }

  window.drawWaterShot = (ctx, localSeconds, shotDuration, assets = {}) => {
    const options = assets.waterGeometry || {};
    const washer = { ...DEFAULT_WASHER, ...options.washer };
    const sea = { ...DEFAULT_SEA, ...options.sea };
    const match = Math.max(0, shotDuration) * (options.matchFraction ?? 0.4);
    const fade = smooth((localSeconds - match + 0.0625) / 0.125);
    if (fade < 1) renderWasher(ctx, localSeconds, match, assets, washer, sea);
    if (fade > 0) renderSea(ctx, Math.max(0, localSeconds - match), assets, sea, fade);
  };

  window.drawSeaShot = (ctx, localSeconds, _shotDuration, assets = {}) => {
    const options = assets.waterGeometry || {};
    const sea = { ...DEFAULT_SEA, ...options.sea };
    renderSea(ctx, localSeconds + (options.seaLeadSeconds ?? 4), assets, sea);
  };
})();
